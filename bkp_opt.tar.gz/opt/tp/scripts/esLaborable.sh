#!/bin/bash

esLaborable() {
  fecha=$1
  dia=$(date -d "$fecha" +"%d")
  mes=$(date -d "$fecha" +"%m")
  anio=$(date -d "$fecha" +"%Y")
  diaSemana=$(date -d "$fecha" +"%u")

mesdia=$mes$dia

 # Verificar feriados
  if [[ ($dia -eq 1 && $mes -eq 1) || ($dia -eq 24 && $mes -eq 3) || ($dia -eq 2 && $mes -eq 4) || ($dia -eq 1 && $mes -eq 5) || ($dia -eq 25 && $mes -eq 5) || ($dia -eq 20 && $mes -eq 6) || ($dia -eq 9 && $mes -eq 7) || ($dia -eq 17 && $mes -eq 8) || ($dia -eq 12 && $mes -eq 10) || ($dia -eq 20 && $mes -eq 11) || ($dia -eq 8 && $mes -eq 12) || ($dia -eq 25 && $mes -eq 12) ]]; then
    case "$mesdia" in
      0101) echo "No laborable. La fecha $fecha es Año Nuevo." ;;
      0324) echo "No Laborable. La fecha $fecha es Día Nacional de la Memoria por la Verdad y la Justicia." ;;
      0402) echo "No Laborable. La fecha $fecha es Lunes de Carnaval." ;;
      0403) echo "No Laborable. La fecha $fecha es Martes de Carnaval." ;;
      0501) echo "No Laborable. La fecha $fecha es Día del Trabajo." ;;
      0525) echo "No Laborable. La fecha $fecha es Día de la Revolución de Mayo." ;;
      0620) echo "No Laborable. La fecha $fecha es Paso a la Inmortalidad del General D. Manuel Belgrano." ;;
      0709) echo "No Laborable. La fecha $fecha es Día de la Independencia." ;;
      0817) echo "No Laborable. La fecha $fecha es Paso a la Inmortalidad del General D. José de San Martín." ;;
      1012) echo "No Laborable. La fecha $fecha es Día del Respeto a la Diversidad Cultural." ;;
      1120) echo "No Laborable. La fecha $fecha es Día de la Soberanía Nacional." ;;
      1208) echo "No Laborable. La fecha $fecha es Día de la Inmaculada Concepción de María." ;;
      1225) echo "No Laborable. La fecha $fecha es Navidad." ;;
    esac
    return 0
  fi

  # Verificar si es fin de semana (sábado = 6, domingo = 7)
  if [[ $diaSemana == 6 || $diaSemana == 7 ]]; then
      echo "No Laborable. La fecha $fecha es fin de semana."
      return 0
  fi

  # No es día no laborable
  echo "Laborable. La fecha $fecha es laborable."
  return 1
}

esLaborable "$@"
