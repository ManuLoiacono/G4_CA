#!/bin/bash

proceso=$1


if systemctl is-active --quiet $proceso; then
   exit 1
else
    echo "El proceso $proceso no se está ejecutando." | mailx -s "Alerta: Proceso $proceso detenido" root
fi

exit 0
