#!/bin/bash

fecha="2023-06-01" # Fecha de ejemplo
/opt/tp/scripts/esLaborable.sh "$fecha"
