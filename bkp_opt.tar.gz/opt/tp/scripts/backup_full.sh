#!/bin/bash

date=$(date +%Y%m%d)

log() {
  echo "$(date +"%T") - $1" >> backup_log.txt
}

#Opcion de ayuda con -h
show_usage() {
  echo "Uso: $0 -o <origen> -d <destino>"
  echo "   -o <origen>: Ruta del filesystem origen a respaldar"
  echo "   -d <destino>: Ruta del filesystem destino para guardar el respaldo"
}


# Manejo de argumentos
while getopts "o:d:h" opt; do
  case $opt in
    o)
      origen=$OPTARG
      ;;
    d)
      destino=$OPTARG
      ;;
    h)
      show_usage
      exit 0
      ;;
    \?)
      echo "Opción inválida: -$OPTARG" >&2
      show_usage
      exit 1
      ;;
  esac
done


# Validar existencia de los filesystems origen y destino
if [ ! -d "$origen" ] || [ ! -d "$destino" ]; then
  log "Error: Los filesystems origen y/o destino no existen" >> backup_log.txt 
  exit 1
fi

# Validar montaje de los filesystems origen y destino
if [ df --output=target "$origen" >/dev/null 2>&1 ] || [ df --output=target "$destino" >/dev/null 2>&1 ]; then
  log "Error: Los filesystems origen y/o destino no están montados" >> backup_log.txt
  exit 1
fi


# Realizar respaldo diario de /etc y /var/log
if [ $(date +%H) -eq 0 ]; then
  log "Realizando respaldo diario de /etc y /var/log." >> backup_log.txt
  tar -czvf "$destino/etc_bkp_$date.tar.gz" /etc
  tar -czvf "$destino/var_logs_bkp_$date.tar.gz" /var/log
  log "Respaldo diario de /etc y /var/log completado." >> backup_log.txt
fi


# Realizar respaldo semanal de /u01 y /u02 los domingos a las 23 hs
if [ $(date +%A) == "Sunday" ] && [ $(date +%H) -eq 23 ]; then
  log "Realizando respaldo semanal de /u01 y /u02." >> backup_log.txt
  tar -czvf "$destino/u01_bkp_$date.tar.gz" /u01
  tar -czvf "$destino/u02_bkp_$date.tar.gz" /u02
  log "Respaldo semanal de /u01 y /u02 completado." >> backup_log.txt
fi

mailx -s "Log de respaldo" root < backup_log.txt
exit 0
